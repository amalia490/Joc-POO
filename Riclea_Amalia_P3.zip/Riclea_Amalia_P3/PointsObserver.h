#pragma once
#include "Observer.h"
#include <SFML/Graphics.hpp>
#include <chrono>

class PointsObserver : public Observer {
    sf::Text& messageText;
    sf::Font& font;
    bool showMessage = false;
    std::chrono::steady_clock::time_point showUntil;
public:
    PointsObserver(sf::Text& text, sf::Font& font) : messageText(text), font(font) {};
    void onPointsChanged(int newPoints) override; 
    void update();
    bool isShowing(); 
};