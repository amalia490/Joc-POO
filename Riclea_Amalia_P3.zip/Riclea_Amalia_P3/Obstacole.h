#pragma once
#include "Coordonate.h"
#include "Minion.h"

class Obstacole {
private:
	std::vector<Coordonate> coordonate;
	int x, y;
public:
	Obstacole(int x, int y);
	virtual void superPower(Minion& minion)=0;
	int getX() const;
	int getY() const;
	//virtual ~Obstacole();
};
