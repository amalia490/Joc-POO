#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include "Subject.h"

class Minion : public Subject {
private:
    static const char name;
    int lvl = 1, lives = 3, x = 0, y = 5, puncte = 0, kiwiP = 0;
    friend std::ostream& operator<<(std::ostream& os, Minion& minion);
    friend std::istream& operator>>(std::istream& is, Minion& minion);
    sf::CircleShape jucator;
    sf::CircleShape cerc;

public:
    Minion();
    Minion(const Minion& other);
    virtual ~Minion() = default;

    virtual void initialize(int x, int y, int lvl, int lives);
    virtual int getX();
    virtual int getY();
    virtual int getLevel();
    virtual int getLives();
    virtual void setLives(int l);
    virtual int getPuncte();
    virtual void setPuncte(int p);
    virtual int getKiwiP();
    virtual void setKiwiP(int p);
    virtual sf::CircleShape getJucator();
    virtual void jump(const int i, const int j);
    virtual void moveUp(int step);
    virtual void moveDown(int step);
    virtual void moveLeft(int step);
    virtual void moveRight(int step);
    virtual void setX(int playerX);
    //virtual int getChange();
    virtual void caracter();
    virtual void draw(sf::RenderWindow* window);
};