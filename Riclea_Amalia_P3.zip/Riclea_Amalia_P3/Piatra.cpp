#include "Piatra.h"

void Piatra::superPower(Minion&  minion) {
	std::cout << "E un simplu perete! Nu afecteaza Minionul!" << std::endl;
}