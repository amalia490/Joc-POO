#include "MinionDecorator.h"

int MinionDecorator::getX() { return wrapped->getX(); }
int MinionDecorator::getY() { return wrapped->getY(); }
int MinionDecorator::getLevel() { return wrapped->getLevel(); }
int MinionDecorator::getLives() { return wrapped->getLives(); }
int MinionDecorator::getPuncte() { return wrapped->getPuncte(); }
void MinionDecorator::setPuncte(int p) { wrapped->setPuncte(p); }
int MinionDecorator::getKiwiP() { return wrapped->getKiwiP(); }
void MinionDecorator::setKiwiP(int p) { wrapped->setKiwiP(p); }
sf::CircleShape MinionDecorator::getJucator() { return wrapped->getJucator(); }
void MinionDecorator::jump(const int i, const int j) { wrapped->jump(i, j); }
void MinionDecorator::moveUp(int step) { wrapped->moveUp(step); }
void MinionDecorator::moveDown(int step) { wrapped->moveDown(step); }
void MinionDecorator::moveLeft(int step) { wrapped->moveLeft(step); }
void MinionDecorator::moveRight(int step) { wrapped->moveRight(step); }
void MinionDecorator::setX(int playerX) { wrapped->setX(playerX); }
void MinionDecorator::setLives(int l) { wrapped->setLives(l); }
//void MinionDecorator::setY(int playerY) { wrapped->setY(playerY); }
void MinionDecorator::caracter() { wrapped->caracter(); }
void MinionDecorator::draw(sf::RenderWindow* window) { wrapped->draw(window); }