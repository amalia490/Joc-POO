#include "Coordonate.h"

Coordonate::Coordonate(int x, int y) {
	this->x = x;
	this->y = y;
}

