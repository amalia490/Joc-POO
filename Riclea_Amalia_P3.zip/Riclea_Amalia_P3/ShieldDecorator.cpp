#pragma once
#include "ShieldDecorator.h"

int ShieldDecorator::getLives() {
    return wrapped->getLives() + 1; // Adds a shield life
}