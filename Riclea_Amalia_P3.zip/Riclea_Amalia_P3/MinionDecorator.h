#pragma once
#include "Minion.h"

class MinionDecorator : public Minion {
protected:
    Minion* wrapped;
public:
    MinionDecorator(Minion* m) : wrapped(m) {}
    virtual ~MinionDecorator() { delete wrapped; }

    // Forward all methods
    int getX() override;
    int getY() override;
    int getLevel() override;
    int getLives() override;
	void setLives(int l) override;
    int getPuncte() override;
    void setPuncte(int p) override;
    int getKiwiP() override;
    void setKiwiP(int p) override;
    sf::CircleShape getJucator() override;
    void jump(const int i, const int j) override;
    void moveUp(int step) override;
    void moveDown(int step) override;
    void moveLeft(int step) override;
    void moveRight(int step) override;
    void setX(int playerX) override;
   // void setY(int playerY) override;
    void caracter() override;
    void draw(sf::RenderWindow* window) override;
};