#pragma once
#include "Subject.h"

void Subject::addObserver(Observer* obs) { observers.push_back(obs); }
void Subject::removeObserver(Observer* obs) {
    observers.erase(std::remove(observers.begin(), observers.end(), obs), observers.end());
}
void Subject::notifyPointsChanged(int newPoints) {
    for (auto* obs : observers)
        obs->onPointsChanged(newPoints);
}