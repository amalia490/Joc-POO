#pragma once
#include "PointsObserver.h"
#include <iostream>

void PointsObserver::onPointsChanged(int newPoints) {
    static int lastPoints = 0;
	std::cout << "MERGE - ON POINTS CHANGED" << std::endl;
	std::cout << "MERGE - NEW POINTS: " << newPoints << " last " << lastPoints << std::endl;
    if (newPoints == 85 && lastPoints < 85) {
		std::cout << "MERGE - YOU WON A LIVE" << std::endl;
        messageText.setFont(font);
        messageText.setString("You won a life!");
        messageText.setCharacterSize(50);
        messageText.setFillColor(sf::Color::Black);
		messageText.setStyle(sf::Text::Bold);
        messageText.setPosition({ 300, 400 });
        showMessage = true;
        showUntil = std::chrono::steady_clock::now() + std::chrono::seconds(1);
    }
    lastPoints = newPoints;
}

void PointsObserver::update() {
    if (showMessage && std::chrono::steady_clock::now() > showUntil) {
        showMessage = false;
        std::cout << "MERGE - UPDATE" << std::endl;

        messageText.setString("");
    }
}

bool PointsObserver::isShowing() { return showMessage; }