#pragma once

class Observer {
public:
    virtual void onPointsChanged(int newPoints) = 0;
    virtual ~Observer() = default;
};