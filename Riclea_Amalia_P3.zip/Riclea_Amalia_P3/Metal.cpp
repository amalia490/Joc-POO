#include "Metal.h"

int Metal::suma = 0;

void Metal::superPower(Minion& minion) {
	Gheata::superPower(minion);
	if (minion.getKiwiP() - 1 >= 0)
		suma = minion.getKiwiP() - 1;
	else
		suma = -1;
	minion.setKiwiP(suma);
	int x = minion.getLives() - 1;
	minion.setLives(x);
	std::cout << suma << std::endl;
}