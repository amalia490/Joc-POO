#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <stack>

class Coordonate {
private:
	int x, y;
public:
	Coordonate(int x, int y);
};
