#pragma once
#include "MinionDecorator.h"

class ShieldDecorator : public MinionDecorator {
public:
    ShieldDecorator(Minion* m) : MinionDecorator(m) {}
    int getLives() override;
};